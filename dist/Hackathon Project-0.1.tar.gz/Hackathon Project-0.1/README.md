#Hackathon project
This library is for recursion and sorting functions

#building this package locally
'python setup.py sdist'

##installing this package from github
pip install git+https://github.com/oarabile96/hackathonProject-python-package.github


###updating this package from github
pip install upgrade git+https://github.com/oarabile96/hackathonProject-python-package.github
